﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri
{
    public partial class OgrenciEkle : Form
    {
        SqlConnection sc = Baglanti.SQLConnection; // Veritabanı bağlantısı sağlayan sınıf
        SqlCommand cmd;
        int tip = 0;
        Models.Ogrenci ogrenci = null;

        private void anaIslemler()
        {
            InitializeComponent();
            groupBox1.Enabled = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            //Açılan ekranı ortalar
            try
            {
                if (sc.State == ConnectionState.Closed)
                {
                    //Veritabanı bağlantısı kapalıysa
                    sc.Open();
                    groupBox1.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public OgrenciEkle()
        {
            anaIslemler();
        }
        public OgrenciEkle(int t) // tip 1 öğrenci ekle, tip 2 öğrenci güncelle
        {
            anaIslemler();
            this.tip = t;
            if (t == 1)
            {
                this.Text = "Öğrenci Ekle";
                this.groupBox1.Text = "Öğrenci Ekle";
                this.btnOgrenciEkle.Text = "Öğrenci Ekle";
                this.groupBox2.Visible = false;
                this.Width = 540;
                this.Height = 385;
            }
            else if (t == 2)
            {
                this.groupBox2.Visible = true;
                this.groupBox1.Visible = false;
                this.Text = "Öğrenci Güncelle";
                this.groupBox1.Text = "Öğrenci Güncelle";
                this.btnOgrenciEkle.Text = "Öğrenci Güncelle";
                this.Width = 540;
                this.Height = 155;
            }
        }

        private void btnOgrenciEkle_Click(object sender, EventArgs e)
        {
            String insertSorgu = "insert into Ogrenci (Ad,Soyad,TCNO,TelefonNo,Email,Adres,Cinsiyet,Kayit_tarihi,Dogum_tarihi) values (@ad,@soyad,@tcno,@telefonno,@email,@adres,@cinsiyet,@kayittarihi,@dogumtarihi)";
            cmd = new SqlCommand(insertSorgu,sc);
            cmd.Parameters.AddWithValue("@ad", txtOgrenciAdi.Text);
            cmd.Parameters.AddWithValue("@soyad", txtOgrenciSoyadi.Text);
            cmd.Parameters.AddWithValue("@tcno", txtOgrenciTcNo.Text);
            cmd.Parameters.AddWithValue("@telefonno", txtOgrenciTelefonNo.Text);
            cmd.Parameters.AddWithValue("@email", txtOgrenciEmail.Text);
            cmd.Parameters.AddWithValue("@adres", txtAdres.Text);

            char harf = ' ';
            if ("Erkek".Equals(cbCinsiyet.SelectedItem.ToString()))
            {
                harf = 'e';
            }
            else
            {
                harf = 'k';
            }
            cmd.Parameters.AddWithValue("@cinsiyet", harf);
            cmd.Parameters.AddWithValue("@kayittarihi", new DateTime().ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("@dogumtarihi", dtDogumTarihi.Value.ToString());
            // sorguyu SqlCommand metoduyla tanımladık.

            int etkilenenSatirSayisi = cmd.ExecuteNonQuery();
            //sorguyu ExecuteNonQuery() metoduyla çalıştırdık
            /*
             Insert,Update ve Delete işlemleri gerçekleştirebilmek için ExecuteNonQuery kullanılır
             */

            if (etkilenenSatirSayisi > 0)
            {
                MessageBox.Show("Öğrenci başarıyla eklendi !");
            }
            else
            {
                MessageBox.Show("Öğrenci eklenemedi !");
            }

        }

        private void btnBilgiGetir_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand();
            cmd.CommandText = "select * from Ogrenci where TCNO=@tcno";
            cmd.Parameters.AddWithValue("@tcno", txtAramaTcNo.Text);
            cmd.Connection = sc;

            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.HasRows) //Eğer select sorgusundan dönen satır varsa
            {
                while (sdr.Read())
                {
                    
                    /*
                     int ID, string Ad, string Soyad, int TCNO, string TelefonNo, string Email, string Adres, char Cinsiyet, string Kayit_tarihi, string Dogum_tarihi
                     */
                    ogrenci = new Models.Ogrenci(
                        int.Parse(sdr["ID"].ToString()),
                        sdr["Ad"].ToString(),
                        sdr["Soyad"].ToString(),
                        sdr["TCNO"].ToString(),
                        sdr["TelefonNo"].ToString(),
                        sdr["Email"].ToString(),
                        sdr["Adres"].ToString(),
                        sdr["Cinsiyet"].ToString()[0],
                        sdr["Kayit_tarihi"].ToString(),
                        sdr["Dogum_tarihi"].ToString()
                    );
                    MessageBox.Show(ogrenci.GetAd()+" "+ogrenci.GetSoyad());
                }
                this.groupBox1.Visible = true;
                this.groupBox2.Visible = false;
                this.Width = 540;
                this.Height = 385;
                txtOgrenciAdi.Text = ogrenci.GetAd();
                txtOgrenciSoyadi.Text = ogrenci.GetSoyad();
                txtAdres.Text = ogrenci.GetAdres();
                txtOgrenciEmail.Text = ogrenci.GetEmail();
                txtOgrenciTelefonNo.Text = ogrenci.GetTelefonNo();
                txtOgrenciTcNo.Text = ogrenci.GetTcNo();
                txtOgrenciTcNo.Enabled = false;
            }
            else
            {
                MessageBox.Show("Öğrenci bulunamadı !");
            }
        }
    }
}
