﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri.GUI
{
    public partial class BransGuncelle : Form
    {
        public BransGuncelle()
        {
            InitializeComponent();
        }

        private void btnBransGuncelle_Click(object sender, EventArgs e)
        {

        }
    }
}
