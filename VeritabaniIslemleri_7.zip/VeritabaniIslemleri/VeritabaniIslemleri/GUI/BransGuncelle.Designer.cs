﻿
namespace VeritabaniIslemleri.GUI
{
    partial class BransGuncelle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEgitimFiyati = new System.Windows.Forms.MaskedTextBox();
            this.txtEgitimSuresi = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBransAciklama = new System.Windows.Forms.TextBox();
            this.txtBransAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBransGuncelle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtEgitimFiyati
            // 
            this.txtEgitimFiyati.Location = new System.Drawing.Point(310, 271);
            this.txtEgitimFiyati.Mask = "00000";
            this.txtEgitimFiyati.Name = "txtEgitimFiyati";
            this.txtEgitimFiyati.Size = new System.Drawing.Size(212, 20);
            this.txtEgitimFiyati.TabIndex = 17;
            this.txtEgitimFiyati.ValidatingType = typeof(int);
            // 
            // txtEgitimSuresi
            // 
            this.txtEgitimSuresi.Location = new System.Drawing.Point(16, 272);
            this.txtEgitimSuresi.Mask = "00000";
            this.txtEgitimSuresi.Name = "txtEgitimSuresi";
            this.txtEgitimSuresi.Size = new System.Drawing.Size(217, 20);
            this.txtEgitimSuresi.TabIndex = 16;
            this.txtEgitimSuresi.ValidatingType = typeof(int);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(307, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Eğitim Fiyatı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 245);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Eğitim Süresi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Branş Açıklaması:";
            // 
            // txtBransAciklama
            // 
            this.txtBransAciklama.Location = new System.Drawing.Point(16, 87);
            this.txtBransAciklama.Multiline = true;
            this.txtBransAciklama.Name = "txtBransAciklama";
            this.txtBransAciklama.Size = new System.Drawing.Size(506, 143);
            this.txtBransAciklama.TabIndex = 12;
            // 
            // txtBransAdi
            // 
            this.txtBransAdi.Location = new System.Drawing.Point(16, 28);
            this.txtBransAdi.Name = "txtBransAdi";
            this.txtBransAdi.Size = new System.Drawing.Size(506, 20);
            this.txtBransAdi.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Branş Adı:";
            // 
            // btnBransGuncelle
            // 
            this.btnBransGuncelle.Location = new System.Drawing.Point(13, 314);
            this.btnBransGuncelle.Name = "btnBransGuncelle";
            this.btnBransGuncelle.Size = new System.Drawing.Size(509, 34);
            this.btnBransGuncelle.TabIndex = 9;
            this.btnBransGuncelle.Text = "Branşı Güncelle";
            this.btnBransGuncelle.UseVisualStyleBackColor = true;
            this.btnBransGuncelle.Click += new System.EventHandler(this.btnBransGuncelle_Click);
            // 
            // BransGuncelle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 361);
            this.Controls.Add(this.txtEgitimFiyati);
            this.Controls.Add(this.txtEgitimSuresi);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBransAciklama);
            this.Controls.Add(this.txtBransAdi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBransGuncelle);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BransGuncelle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Branş Güncelle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox txtEgitimFiyati;
        private System.Windows.Forms.MaskedTextBox txtEgitimSuresi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBransAciklama;
        private System.Windows.Forms.TextBox txtBransAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBransGuncelle;
    }
}