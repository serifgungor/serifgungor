﻿
namespace VeritabaniIslemleri
{
    partial class AnaEkran
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.cikisMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciOnkayitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciEkleMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciSilMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciListeleMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciGuncelleMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ogrenciSertifika = new System.Windows.Forms.ToolStripMenuItem();
            this.ogrenciBransSorgula = new System.Windows.Forms.ToolStripMenuItem();
            this.egitimMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.egitimVerilenGrupMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.egitimVerilenGrupOgrenciMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.egitimVerilenGrupSaatleriMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.egitimSorulariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.egitimYanitlariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.egitimYoklamalari = new System.Windows.Forms.ToolStripMenuItem();
            this.sinavlarMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.sinavlariListeleMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.sinavSorulariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.sinavYanitlariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.sinavPuanlariMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.ogrenciMenu,
            this.egitimMenu,
            this.sinavlarMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cikisMenu});
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(51, 20);
            this.fileMenu.Text = "Dosya";
            // 
            // cikisMenu
            // 
            this.cikisMenu.Name = "cikisMenu";
            this.cikisMenu.Size = new System.Drawing.Size(99, 22);
            this.cikisMenu.Text = "Çıkış";
            this.cikisMenu.Click += new System.EventHandler(this.cikisMenu_Click);
            // 
            // ogrenciMenu
            // 
            this.ogrenciMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ogrenciOnkayitMenu,
            this.ogrenciEkleMenu,
            this.ogrenciSilMenu,
            this.ogrenciListeleMenu,
            this.ogrenciGuncelleMenu,
            this.toolStripSeparator1,
            this.ogrenciSertifika,
            this.ogrenciBransSorgula});
            this.ogrenciMenu.Name = "ogrenciMenu";
            this.ogrenciMenu.Size = new System.Drawing.Size(61, 20);
            this.ogrenciMenu.Text = "Öğrenci";
            // 
            // ogrenciOnkayitMenu
            // 
            this.ogrenciOnkayitMenu.Name = "ogrenciOnkayitMenu";
            this.ogrenciOnkayitMenu.Size = new System.Drawing.Size(191, 22);
            this.ogrenciOnkayitMenu.Text = "Öğrenci Önkayıt";
            // 
            // ogrenciEkleMenu
            // 
            this.ogrenciEkleMenu.Name = "ogrenciEkleMenu";
            this.ogrenciEkleMenu.Size = new System.Drawing.Size(191, 22);
            this.ogrenciEkleMenu.Text = "Öğrenci Ekle";
            this.ogrenciEkleMenu.Click += new System.EventHandler(this.ogrenciEkleMenu_Click);
            // 
            // ogrenciSilMenu
            // 
            this.ogrenciSilMenu.Name = "ogrenciSilMenu";
            this.ogrenciSilMenu.Size = new System.Drawing.Size(191, 22);
            this.ogrenciSilMenu.Text = "Öğrenci Sil";
            this.ogrenciSilMenu.Click += new System.EventHandler(this.ogrenciSilMenu_Click);
            // 
            // ogrenciListeleMenu
            // 
            this.ogrenciListeleMenu.Name = "ogrenciListeleMenu";
            this.ogrenciListeleMenu.Size = new System.Drawing.Size(191, 22);
            this.ogrenciListeleMenu.Text = "Öğrenci Listele";
            this.ogrenciListeleMenu.Click += new System.EventHandler(this.ogrenciListeleMenu_Click);
            // 
            // ogrenciGuncelleMenu
            // 
            this.ogrenciGuncelleMenu.Name = "ogrenciGuncelleMenu";
            this.ogrenciGuncelleMenu.Size = new System.Drawing.Size(191, 22);
            this.ogrenciGuncelleMenu.Text = "Öğrenci Güncelle";
            this.ogrenciGuncelleMenu.Click += new System.EventHandler(this.ogrenciGuncelleMenu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(188, 6);
            // 
            // ogrenciSertifika
            // 
            this.ogrenciSertifika.Name = "ogrenciSertifika";
            this.ogrenciSertifika.Size = new System.Drawing.Size(191, 22);
            this.ogrenciSertifika.Text = "Öğrenci Sertifikaları";
            // 
            // ogrenciBransSorgula
            // 
            this.ogrenciBransSorgula.Name = "ogrenciBransSorgula";
            this.ogrenciBransSorgula.Size = new System.Drawing.Size(191, 22);
            this.ogrenciBransSorgula.Text = "Öğrenci Branş Sorgula";
            // 
            // egitimMenu
            // 
            this.egitimMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.egitimVerilenGrupMenu,
            this.egitimVerilenGrupOgrenciMenu,
            this.egitimVerilenGrupSaatleriMenu,
            this.toolStripSeparator2,
            this.egitimSorulariMenu,
            this.egitimYanitlariMenu,
            this.toolStripSeparator3,
            this.egitimYoklamalari});
            this.egitimMenu.Name = "egitimMenu";
            this.egitimMenu.Size = new System.Drawing.Size(53, 20);
            this.egitimMenu.Text = "Eğitim";
            // 
            // egitimVerilenGrupMenu
            // 
            this.egitimVerilenGrupMenu.Name = "egitimVerilenGrupMenu";
            this.egitimVerilenGrupMenu.Size = new System.Drawing.Size(220, 22);
            this.egitimVerilenGrupMenu.Text = "Eğitim Verilen Gruplar";
            // 
            // egitimVerilenGrupOgrenciMenu
            // 
            this.egitimVerilenGrupOgrenciMenu.Name = "egitimVerilenGrupOgrenciMenu";
            this.egitimVerilenGrupOgrenciMenu.Size = new System.Drawing.Size(220, 22);
            this.egitimVerilenGrupOgrenciMenu.Text = "Eğitim Verilen Grup Öğrenci";
            // 
            // egitimVerilenGrupSaatleriMenu
            // 
            this.egitimVerilenGrupSaatleriMenu.Name = "egitimVerilenGrupSaatleriMenu";
            this.egitimVerilenGrupSaatleriMenu.Size = new System.Drawing.Size(220, 22);
            this.egitimVerilenGrupSaatleriMenu.Text = "Eğitim Verilen Grup Saatleri";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(217, 6);
            // 
            // egitimSorulariMenu
            // 
            this.egitimSorulariMenu.Name = "egitimSorulariMenu";
            this.egitimSorulariMenu.Size = new System.Drawing.Size(220, 22);
            this.egitimSorulariMenu.Text = "Eğitim Soruları";
            // 
            // egitimYanitlariMenu
            // 
            this.egitimYanitlariMenu.Name = "egitimYanitlariMenu";
            this.egitimYanitlariMenu.Size = new System.Drawing.Size(220, 22);
            this.egitimYanitlariMenu.Text = "Eğitim Yanıtları";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(217, 6);
            // 
            // egitimYoklamalari
            // 
            this.egitimYoklamalari.Name = "egitimYoklamalari";
            this.egitimYoklamalari.Size = new System.Drawing.Size(220, 22);
            this.egitimYoklamalari.Text = "Eğitim Yoklamaları";
            // 
            // sinavlarMenu
            // 
            this.sinavlarMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sinavlariListeleMenu,
            this.sinavSorulariMenu,
            this.sinavYanitlariMenu,
            this.sinavPuanlariMenu});
            this.sinavlarMenu.Name = "sinavlarMenu";
            this.sinavlarMenu.Size = new System.Drawing.Size(60, 20);
            this.sinavlarMenu.Text = "Sınavlar";
            // 
            // sinavlariListeleMenu
            // 
            this.sinavlariListeleMenu.Name = "sinavlariListeleMenu";
            this.sinavlariListeleMenu.Size = new System.Drawing.Size(154, 22);
            this.sinavlariListeleMenu.Text = "Sınavları Listele";
            // 
            // sinavSorulariMenu
            // 
            this.sinavSorulariMenu.Name = "sinavSorulariMenu";
            this.sinavSorulariMenu.Size = new System.Drawing.Size(154, 22);
            this.sinavSorulariMenu.Text = "Sınav Soruları";
            // 
            // sinavYanitlariMenu
            // 
            this.sinavYanitlariMenu.Name = "sinavYanitlariMenu";
            this.sinavYanitlariMenu.Size = new System.Drawing.Size(154, 22);
            this.sinavYanitlariMenu.Text = "Sınav Yanıtları";
            // 
            // sinavPuanlariMenu
            // 
            this.sinavPuanlariMenu.Name = "sinavPuanlariMenu";
            this.sinavPuanlariMenu.Size = new System.Drawing.Size(154, 22);
            this.sinavPuanlariMenu.Text = "Sınav Puanları";
            // 
            // AnaEkran
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AnaEkran";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AnaEkran";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AnaEkran_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem cikisMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciEkleMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciListeleMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciGuncelleMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciOnkayitMenu;
        private System.Windows.Forms.ToolStripMenuItem ogrenciSertifika;
        private System.Windows.Forms.ToolStripMenuItem ogrenciBransSorgula;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem egitimMenu;
        private System.Windows.Forms.ToolStripMenuItem egitimVerilenGrupMenu;
        private System.Windows.Forms.ToolStripMenuItem egitimVerilenGrupOgrenciMenu;
        private System.Windows.Forms.ToolStripMenuItem egitimVerilenGrupSaatleriMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem egitimSorulariMenu;
        private System.Windows.Forms.ToolStripMenuItem egitimYanitlariMenu;
        private System.Windows.Forms.ToolStripMenuItem sinavlarMenu;
        private System.Windows.Forms.ToolStripMenuItem sinavlariListeleMenu;
        private System.Windows.Forms.ToolStripMenuItem sinavSorulariMenu;
        private System.Windows.Forms.ToolStripMenuItem sinavYanitlariMenu;
        private System.Windows.Forms.ToolStripMenuItem sinavPuanlariMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem egitimYoklamalari;
        private System.Windows.Forms.ToolStripMenuItem ogrenciSilMenu;
    }
}