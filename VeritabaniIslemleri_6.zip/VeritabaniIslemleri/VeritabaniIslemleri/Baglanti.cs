﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeritabaniIslemleri
{
    public class Baglanti
    {
        public static string Sunucu
        {
            get
            {
                return "Server=DESKTOP-H19IAS6\\SQLEXPRESS;";
            }
        }
        public static string Veritabani
        {
            get
            {
                return "Database=OnlineEgitim;";
            }
        }
        public static string BaglantiCumlesi
        {
            get
            {
                return Sunucu+ Veritabani + "Trusted_Connection=True";
            }
        }
        public static SqlConnection SQLConnection
        {
            get
            {
                return new SqlConnection(BaglantiCumlesi);
            }
        }
    }
}
