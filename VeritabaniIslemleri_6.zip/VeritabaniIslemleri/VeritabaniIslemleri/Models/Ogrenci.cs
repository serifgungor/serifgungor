﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeritabaniIslemleri.Models
{
    class Ogrenci
    {
        private int ID;
        private string Ad;
        private string Soyad;
        private string TCNO;
        private string TelefonNo;
        private string Email;
        private string Adres;
        private char Cinsiyet;
        private string Kayit_tarihi;
        private string Dogum_tarihi;

        public Ogrenci(){}
        public Ogrenci(int ID, string Ad, string Soyad, string TCNO, string TelefonNo, string Email, string Adres, char Cinsiyet, string Kayit_tarihi, string Dogum_tarihi)
        {
            this.ID = ID;
            this.Ad = Ad;
            this.Soyad = Soyad;
            this.TelefonNo = TelefonNo;
            this.Email = Email;
            this.Adres = Adres;
            this.Cinsiyet = Cinsiyet;
            this.Kayit_tarihi = Kayit_tarihi;
            this.Dogum_tarihi = Dogum_tarihi;
            this.TCNO = TCNO;
        }

        public int GetId()
        {
            return this.ID;
        }
        public string GetTcNo()
        {
            return this.TCNO;
        }
        public string GetAd()
        {
            return this.Ad;
        }
        public string GetSoyad()
        {
            return this.Soyad;
        }
        public string GetTelefonNo()
        {
            return this.TelefonNo;
        }
        public string GetEmail()
        {
            return this.Email;
        }
        public string GetAdres()
        {
            return this.Adres;
        }
        public char GetCinsiyet()
        {
            return this.Cinsiyet;
        }
        public string GetKayitTarihi()
        {
            return this.Kayit_tarihi;
        }
        public string GetDogumTarihi()
        {
            return this.Dogum_tarihi;
        }

    }
}
