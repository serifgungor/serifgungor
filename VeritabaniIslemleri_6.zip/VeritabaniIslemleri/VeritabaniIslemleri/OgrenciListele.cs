﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri
{
    public partial class OgrenciListele : Form
    {
        private List<Models.Ogrenci> ogrenciler;
        SqlConnection sc = Baglanti.SQLConnection;
        SqlCommand cmd = null;
        SqlDataReader sdr = null;
        public OgrenciListele()
        {
            InitializeComponent();
            ogrenciler = new List<Models.Ogrenci>();
            if(sc.State == ConnectionState.Closed)
            {
                sc.Open();
            }
            cmd = new SqlCommand("select * from Ogrenci", sc);
            sdr = cmd.ExecuteReader();

            Models.Ogrenci ogrenci;

            while (sdr.Read())
            {
                /*
                 int ID, string Ad, string Soyad, string TCNO, string TelefonNo, string Email, string Adres, char Cinsiyet, string Kayit_tarihi, string Dogum_tarihi
                 */
                ogrenci = new Models.Ogrenci(
                        int.Parse(sdr["ID"].ToString()),
                        sdr["Ad"].ToString(),
                        sdr["Soyad"].ToString(),
                        sdr["TCNO"].ToString(),
                        sdr["TelefonNo"].ToString(),
                        sdr["Email"].ToString(),
                        sdr["Adres"].ToString(),
                        sdr["Cinsiyet"].ToString()[0],
                        sdr["Kayit_tarihi"].ToString(),
                        sdr["Dogum_tarihi"].ToString()
                 );
                ogrenciler.Add(ogrenci);
            }

            lvOgrenciler.Columns.Add("ID", 100);
            lvOgrenciler.Columns.Add("Ad Soyad", 100);
            lvOgrenciler.Columns.Add("TC NO", 100);
            lvOgrenciler.Columns.Add("Telefon NO", 100);
            lvOgrenciler.Columns.Add("Email", 100);
            lvOgrenciler.Columns.Add("Adres", 100);
            lvOgrenciler.Columns.Add("Cinsiyet", 60);
            lvOgrenciler.Columns.Add("KayitTarihi", 100);
            lvOgrenciler.Columns.Add("DogumTarihi", 100);
          
            ListViewItem item; //itemleri ListView nesnemize ekliyoruz.

            string[] dizi = new string[9];
            foreach (Models.Ogrenci o in ogrenciler)
            {
                dizi[0] = o.GetId()+"";
                dizi[1] = o.GetAd()+" "+o.GetSoyad();
                dizi[2] = o.GetTcNo() + "";
                dizi[3] = o.GetTelefonNo() + "";
                dizi[4] = o.GetEmail() + "";
                dizi[5] = o.GetAdres() + "";
                if (o.GetCinsiyet() == 'e')
                {
                    dizi[6] = "Erkek";
                }
                else
                {
                    dizi[6] = "Kadın";
                }
                dizi[7] = o.GetKayitTarihi() + "";
                dizi[8] = o.GetDogumTarihi() + "";
                item = new ListViewItem(dizi);
                lvOgrenciler.Items.Add(item);
            }


            lvOgrenciler.View = View.Details;
            lvOgrenciler.GridLines = true;
            lvOgrenciler.FullRowSelect = true;



        }

        private void OgrenciListele_Load(object sender, EventArgs e)
        {
            
        }
    }
}
