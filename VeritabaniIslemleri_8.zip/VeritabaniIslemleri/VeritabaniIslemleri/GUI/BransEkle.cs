﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri.GUI
{
    public partial class BransEkle : Form
    {
        public BransEkle()
        {
            InitializeComponent();
        }

        private void btnBransEkle_Click(object sender, EventArgs e)
        {

        }
    }
}
