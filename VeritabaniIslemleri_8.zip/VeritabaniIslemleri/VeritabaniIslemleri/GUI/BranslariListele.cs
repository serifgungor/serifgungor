﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri.GUI
{
    public partial class BranslariListele : Form
    {
        SqlConnection sc = Baglanti.SQLConnection;
        SqlDataAdapter sda = null;
        //Select sorgusundan dönen sonuçları yakalayabilmek için kullanılan sınıftır.
        DataSet ds = new DataSet();
        //SqlDataAdapter'dan dönen verileri saklayabileceğimiz nesnedir. Bu nesne aynı zamanda DataGridView nesnesini doldurabilmek için gereklidir.
        public BranslariListele()
        {
            InitializeComponent();
            if (sc.State == ConnectionState.Closed)
            {
                sc.Open();
                string selectSorgusu = "select * from Brans";
                sda = new SqlDataAdapter(selectSorgusu, sc);
            }
            sda.Fill(ds, "Brans");
            //Brans tablosundaki tüm değerleri DataSet nesnesine gönderir.
            dataGridView1.DataSource = ds;
            //DataGridView nesnesini DataSet ile doldurduk.
            dataGridView1.DataMember = "Brans";
            //Verileri gösterebileceğimiz veritabanı tablo adını belirttik.
            dataGridView1.MultiSelect = false; //Çoklu seçimi iptal ettik
        }

        private void btnBransGuncelle_Click(object sender, EventArgs e)
        {
            //Branş güncelle butonuna tıklandığında seçilen DataGridView satırının değerleri, Açılan BransGuncelle sayfasına iletilir.
            int id = int.Parse(dataGridView1.CurrentRow.Cells["id"].Value.ToString());
            string ad = dataGridView1.CurrentRow.Cells["Ad"].Value.ToString();
            string egitimicerigi = dataGridView1.CurrentRow.Cells["EgitimIcerigi"].Value.ToString();
            int sure = int.Parse(dataGridView1.CurrentRow.Cells["EgitimSuresi"].Value.ToString());
            double egitimFiyati = double.Parse(dataGridView1.CurrentRow.Cells["EgitimFiyati"].Value.ToString());
            BransGuncelle bg = new BransGuncelle(id,sure,ad,egitimicerigi,egitimFiyati);
            bg.Show();
        }

        private void btnBransSil_Click(object sender, EventArgs e)
        {

        }

        private void btnBransEkle_Click(object sender, EventArgs e)
        {
            BransEkle be = new BransEkle();
            be.MdiParent = AnaEkran.ActiveForm;
            be.BringToFront();
            be.Show();
        }
    }
}
