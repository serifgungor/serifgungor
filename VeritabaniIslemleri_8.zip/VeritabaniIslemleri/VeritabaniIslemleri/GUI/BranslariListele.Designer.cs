﻿
namespace VeritabaniIslemleri.GUI
{
    partial class BranslariListele
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnBransGuncelle = new System.Windows.Forms.Button();
            this.btnBransSil = new System.Windows.Forms.Button();
            this.btnBransEkle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 50);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(775, 388);
            this.dataGridView1.TabIndex = 0;
            // 
            // btnBransGuncelle
            // 
            this.btnBransGuncelle.Location = new System.Drawing.Point(580, 12);
            this.btnBransGuncelle.Name = "btnBransGuncelle";
            this.btnBransGuncelle.Size = new System.Drawing.Size(101, 32);
            this.btnBransGuncelle.TabIndex = 1;
            this.btnBransGuncelle.Text = "Branş Güncelle";
            this.btnBransGuncelle.UseVisualStyleBackColor = true;
            this.btnBransGuncelle.Click += new System.EventHandler(this.btnBransGuncelle_Click);
            // 
            // btnBransSil
            // 
            this.btnBransSil.Location = new System.Drawing.Point(687, 12);
            this.btnBransSil.Name = "btnBransSil";
            this.btnBransSil.Size = new System.Drawing.Size(101, 32);
            this.btnBransSil.TabIndex = 2;
            this.btnBransSil.Text = "Branş Sil";
            this.btnBransSil.UseVisualStyleBackColor = true;
            this.btnBransSil.Click += new System.EventHandler(this.btnBransSil_Click);
            // 
            // btnBransEkle
            // 
            this.btnBransEkle.Location = new System.Drawing.Point(13, 12);
            this.btnBransEkle.Name = "btnBransEkle";
            this.btnBransEkle.Size = new System.Drawing.Size(101, 32);
            this.btnBransEkle.TabIndex = 3;
            this.btnBransEkle.Text = "Branş Ekle";
            this.btnBransEkle.UseVisualStyleBackColor = true;
            this.btnBransEkle.Click += new System.EventHandler(this.btnBransEkle_Click);
            // 
            // BranslariListele
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBransEkle);
            this.Controls.Add(this.btnBransSil);
            this.Controls.Add(this.btnBransGuncelle);
            this.Controls.Add(this.dataGridView1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BranslariListele";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Branşları Listele";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnBransGuncelle;
        private System.Windows.Forms.Button btnBransSil;
        private System.Windows.Forms.Button btnBransEkle;
    }
}