﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri
{
    public partial class OgrenciSil : Form
    {
        SqlConnection sc = Baglanti.SQLConnection;
        SqlCommand cmd;
        public OgrenciSil()
        {
            InitializeComponent();
        }
        private void OgrenciSil_Load(object sender, EventArgs e)
        {
            if(sc.State == ConnectionState.Closed)
            {
                sc.Open();
            }
        }

        private void btnKaldir_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from Ogrenci where TCNO=@tcno", sc);
            cmd.Parameters.AddWithValue("@tcno", txtTcNo.Text);
            int sonucSayisi = cmd.ExecuteNonQuery();
            if (sonucSayisi > 0)
            {
                MessageBox.Show("Öğrenci sistemden silindi");
            }
            else
            {
                MessageBox.Show("Öğrenci silinemedi");
            }
        }

        
    }
}
