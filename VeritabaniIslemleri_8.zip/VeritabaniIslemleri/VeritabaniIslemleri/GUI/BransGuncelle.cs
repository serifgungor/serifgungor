﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri.GUI
{
    public partial class BransGuncelle : Form
    {
        int id = 0, egitimsuresi=0;
        string ad="", aciklama="";
        double egitimfiyati = 0;

        SqlConnection sc = Baglanti.SQLConnection;
        SqlCommand cmd;

        public BransGuncelle()
        {
            InitializeComponent();
        }

        public BransGuncelle(int id,int egitimsuresi,string ad,string aciklama,double egitimfiyati)
        {
            InitializeComponent();
            this.id = id;
            this.egitimsuresi = egitimsuresi;
            this.ad = ad;
            this.aciklama = aciklama;
            this.egitimfiyati = egitimfiyati;

            txtBransAdi.Text = ad;
            txtEgitimFiyati.Text = egitimfiyati.ToString();
            txtEgitimSuresi.Text = egitimsuresi.ToString();
            txtBransAciklama.Text = aciklama;

            try
            {
                if (sc.State == ConnectionState.Closed)
                {
                    sc.Open();
                }
            }
            catch(Exception e){
                MessageBox.Show("Veritabanına bağlanılamadı !");
            }
        }

        private void btnBransGuncelle_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("update Brans set Ad=@ad,EgitimIcerigi=@ei,EgitimSuresi=@es,EgitimFiyati=@ef where ID=@id",sc);

            cmd.Parameters.AddWithValue("@id", id);
            cmd.Parameters.AddWithValue("@ad", txtBransAdi.Text);
            cmd.Parameters.AddWithValue("@ei", txtBransAciklama.Text);
            cmd.Parameters.AddWithValue("@es", txtEgitimSuresi.Text);
            cmd.Parameters.AddWithValue("@ef", txtEgitimFiyati.Text);

            int count = cmd.ExecuteNonQuery();
            if (count > 0)
            {
                MessageBox.Show("Branş bilgileri başarıyla güncellendi.");
            }
            else
            {
                MessageBox.Show("Branş bilgileri güncellenemedi.");
            }
           

        }
    }
}
