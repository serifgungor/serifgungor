﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri
{
    public partial class OgrenciEkle : Form
    {
        SqlConnection sc = Baglanti.SQLConnection; // Veritabanı bağlantısı sağlayan sınıf
        SqlCommand cmd;
        public OgrenciEkle()
        {
            InitializeComponent();
            groupBox1.Enabled = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            //Açılan ekranı ortalar
            try
            {
                if (sc.State == ConnectionState.Closed)
                {
                    //Veritabanı bağlantısı kapalıysa
                    sc.Open();
                    groupBox1.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnOgrenciEkle_Click(object sender, EventArgs e)
        {
            String insertSorgu = "insert into Ogrenci (Ad,Soyad,TCNO,TelefonNo,Email,Adres,Cinsiyet,Kayit_tarihi,Dogum_tarihi) values (@ad,@soyad,@tcno,@telefonno,@email,@adres,@cinsiyet,@kayittarihi,@dogumtarihi)";
            cmd = new SqlCommand(insertSorgu,sc);
            cmd.Parameters.AddWithValue("@ad", txtOgrenciAdi.Text);
            cmd.Parameters.AddWithValue("@soyad", txtOgrenciSoyadi.Text);
            cmd.Parameters.AddWithValue("@tcno", txtOgrenciTcNo.Text);
            cmd.Parameters.AddWithValue("@telefonno", txtOgrenciTelefonNo.Text);
            cmd.Parameters.AddWithValue("@email", txtOgrenciEmail.Text);
            cmd.Parameters.AddWithValue("@adres", txtAdres.Text);

            char harf = ' ';
            if ("Erkek".Equals(cbCinsiyet.SelectedItem.ToString()))
            {
                harf = 'e';
            }
            else
            {
                harf = 'k';
            }
            cmd.Parameters.AddWithValue("@cinsiyet", harf);
            cmd.Parameters.AddWithValue("@kayittarihi", new DateTime().ToString("yyyy-MM-dd HH:mm"));
            cmd.Parameters.AddWithValue("@dogumtarihi", dtDogumTarihi.Value.ToString());
            // sorguyu SqlCommand metoduyla tanımladık.

            int etkilenenSatirSayisi = cmd.ExecuteNonQuery();
            //sorguyu ExecuteNonQuery() metoduyla çalıştırdık
            /*
             Insert,Update ve Delete işlemleri gerçekleştirebilmek için ExecuteNonQuery kullanılır
             */

            if (etkilenenSatirSayisi > 0)
            {
                MessageBox.Show("Öğrenci başarıyla eklendi !");
            }
            else
            {
                MessageBox.Show("Öğrenci eklenemedi !");
            }

        }
    }
}
