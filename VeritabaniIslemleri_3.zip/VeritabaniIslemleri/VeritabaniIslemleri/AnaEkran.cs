﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VeritabaniIslemleri
{
    public partial class AnaEkran : Form
    {
        public AnaEkran()
        {
            InitializeComponent();
        }

        private void AnaEkran_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
        }

        private void cikisMenu_Click(object sender, EventArgs e)
        {
            this.Close(); //Uygulamayı kapatır
        }

        private void ogrenciEkleMenu_Click(object sender, EventArgs e)
        {
            OgrenciEkle oe = new OgrenciEkle();
            oe.MdiParent = this;
            oe.BringToFront();
            oe.Show(); //
        }

        private void ogrenciSilMenu_Click(object sender, EventArgs e)
        {
            OgrenciSil oe = new OgrenciSil();
            oe.MdiParent = this;
            oe.BringToFront();
            oe.Show(); //
        }
    }
}
